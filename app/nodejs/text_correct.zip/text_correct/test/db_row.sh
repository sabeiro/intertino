curl -X POST -H "Content-Type: application/json" -d @row_db.json http://localhost/intertino/node/geocode/lib/db.php

curl -X POST -H "Content-Type: application/json" -d @row_db.json http://dauvi.org/intertino/node/geocode/lib/db.php

